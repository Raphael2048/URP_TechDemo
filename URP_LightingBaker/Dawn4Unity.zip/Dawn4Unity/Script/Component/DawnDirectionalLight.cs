﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

#if UNITY_EDITOR

namespace GPUBaking
{
	[ExecuteInEditMode]
	[DisallowMultipleComponent]
	public class DawnDirectionalLight : DawnBaseLight {
		[HideInInspector]
		public float LightSourceAngle = 1.0f;
		public float ShadowSpread = 0.01f;
	}
}

#endif