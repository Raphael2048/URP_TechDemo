﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

#if UNITY_EDITOR

namespace GPUBaking
{
	[ExecuteInEditMode]
	[DisallowMultipleComponent]
	public class DawnPointLight : DawnBaseLight {
		public enum FalloffMode
		{
			InverseSquaredFalloff = 0,
			BakeryFalloff = 1,
			UnityFalloff = 2
		};
		public  FalloffMode falloffMode= 0;
		public float sourceRadius = 0.0f;
		[HideInInspector]
		public float sourceLength = 0.0f;
		public float lightFalloffExponent = 1.0f;
	}
}

#endif
