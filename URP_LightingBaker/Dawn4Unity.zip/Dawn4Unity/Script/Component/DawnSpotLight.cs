﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

#if UNITY_EDITOR

namespace GPUBaking
{
	[ExecuteInEditMode]
	[DisallowMultipleComponent]
	public class DawnSpotLight : DawnPointLight {
		public float innerConeAngle = 0.0f;
	}
}

#endif
