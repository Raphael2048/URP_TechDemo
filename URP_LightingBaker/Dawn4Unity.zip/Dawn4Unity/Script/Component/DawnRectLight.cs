﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

#if UNITY_EDITOR

namespace GPUBaking
{
	[ExecuteInEditMode]
	[DisallowMultipleComponent]
	public class DawnRectLight : DawnBaseLight {
		public float AttenuationRadius = 0;
		[HideInInspector]
		public float barnDoorLength = 0.2f;
		[HideInInspector]
		public float barnDoorAngle = 88;
		public float lightFalloffExponent = 1.0f;
	}
}

#endif