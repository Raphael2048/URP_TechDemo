﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace GPUBaking
{
	[ExecuteInEditMode]
	[DisallowMultipleComponent]
	public abstract class  DawnBaseLight : MonoBehaviour {
		public bool UpdateWithUnity = false;
		public bool bUseTemperature = false;

		public Color color = Color.white;
		public float intensity = 1.0f;
		public float indirectMultiplier = 1.0f;

		#if UNITY_EDITOR
		protected Light UnityLight;

		protected virtual void Update()
		{
			if(UnityLight == null)
			{
				UnityLight = GetComponent<Light>();
			}
			if(UnityLight!=null && UpdateWithUnity)
			{
				color = UnityLight.color;
				intensity = UnityLight.intensity;
				indirectMultiplier = UnityLight.bounceIntensity;
			}
		}

		#endif
	}
}