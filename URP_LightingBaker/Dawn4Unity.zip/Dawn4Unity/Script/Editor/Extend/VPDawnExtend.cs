﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using GPUBaking;
using GPUBaking.Editor;
using UnityEditor;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace GPUBaking.Editor
{

    public class VPDawnBakePathSetting : DawnBakePathSetting
    {
        public VPDawnBakePathSetting(Scene CurrentScene) : base(CurrentScene)
        {
        }
        public override string DawnLightingAssetPath(bool bCreateIfNotExist = true)
        {
            BakeResultFolderPath(bCreateIfNotExist);
            return String.Format("{0}"+ CurrentScene.name+".asset", BakeResultFolderPathPrefix());
        }
        // This path should begin with "Assets/"
        public override string BakeResultFolderPath(bool bCreateIfNotExist = false)
        {
            string ExportFolder = CurrentScene.path.Split('.')[0];
            if (bCreateIfNotExist) {
                CreateFolderIfNotExist (ExportFolder);
            }
            return ExportFolder;
        }

        protected override string BakeResultFolderPathPrefix ()
        {
            return BakeResultFolderPath () + "/";
        }

        protected override string BakeTempFolderName ()
        {
            return "DawnTemp";
        }
        // public override string BakeResultFolderPath(bool bCreateIfNotExist = false)
        // {
        //     var scene = SceneManager.GetActiveScene();
        //     string rootPath = Path.Combine("Assets/", SceneDataProcessTool.SceneOutputPath);
        //     rootPath = FileTools.FormatPath(rootPath);
        //     string bakePath = rootPath + "/" + scene.name + "/Bake";
        //     FileTools.CreateDirectory(bakePath);
        //
        //     if (bCreateIfNotExist)
        //     {
        //         CreateFolderIfNotExist(bakePath);
        //     }
        //
        //     AssetDatabase.Refresh();
        //
        //     return bakePath;
        // }

     

        //
        // protected override string BakeResultFolderPathPrefix()
        // {
        //     var CurrentScene = SceneManager.GetActiveScene();
        //
        //     return BakeResultFolderPath(true) + "/" + CurrentScene.name + "_";
        // }
        //
        // protected override string BakeTempFolderName()
        // {
        //     var CurrentScene = SceneManager.GetActiveScene();
        //
        //     return CurrentScene.name + "Temp";
        // }
        //
        // protected override string BakeTempFolderPath(bool bCreateIfNotExist = true)
        // {
        //     string TempFolderName = BakeTempFolderName();
        //     var CurrentScene = SceneManager.GetActiveScene();
        //     string path = CurrentScene.path;
        //     int PathIndex = path.LastIndexOf("/");
        //     string ParentPath = path.Substring(0, PathIndex);
        //     string TempFolderPath = string.Format("{0}/{1}", ParentPath, TempFolderName);
        //
        //     string fullpath = FileTools.FormatBasePathToUnityAssetPath(TempFolderPath);
        //     fullpath = FileTools.FormatPath(fullpath);
        //     FileTools.CreateDirectory(fullpath);
        //
        //     AssetDatabase.Refresh();
        //
        //     return TempFolderPath;
        // }

    }

}
