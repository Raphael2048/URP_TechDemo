﻿using System;

namespace GPUBaking.Editor
{
    /// <summary>
    /// Rectangle wrapper, keep a canvas in it. 
    /// Split the canvas into cells, use rows and columns to locate the cells.
    /// The canvas layout will update (split more rows or columns) after adding a rectangle each time.
    /// </summary>
    public class RectWrapper
    {
        private int Width;
        private int Height;

        private int MaxValidWidth;
        private int MaxValidHeight;

        private long SpaceLeft;// the total free space of canvas right, use to quickly check if the rectangle is too large to place.

        private Dynamic2DArray<bool> CanvasCells = new Dynamic2DArray<bool>();
        public RectWrapper(int width, int height)
        {
            Width = width;
            Height = height;

            MaxValidWidth = 0;
            MaxValidHeight = 0;
            SpaceLeft = Width * Height;
            Init();
        }

        public void Init()
        {
            CanvasCells.Init(Width, Height, false);
        }

        /// <summary>
        /// try to add rectangle to the canvas
        /// </summary>
        /// <param name="rectWidth">rectangle width</param>
        /// <param name="rectHeight">rectangle height</param>
        /// <param name="rectOffsetX">the offset x of the rectangle in this canvas</param>
        /// <param name="rectOffsetY">the offset y of the rectangle in this canvas</param>
        /// <param name="lowestDeficit">if failed, this show the lowest height deficit.</param>
        /// <returns></returns>
        public bool AddRectangle(int rectWidth, int rectHeight, out int rectOffsetX, out int rectOffsetY, out int lowestDeficit, EPackedOrder PackedOrder = EPackedOrder.Diagonal)
        {
            rectOffsetX = 0;
            rectOffsetY = 0;
            lowestDeficit = 0;

            if (rectWidth * rectHeight > SpaceLeft)
            {                
                // no enough space for this rectangle
                return false;
            }

            int requiredWidth = rectWidth;
            int requiredHeight = rectHeight;
            bool rectangleWasPlaced = false;

            switch(PackedOrder)
            {
                case EPackedOrder.HeightFirst:
                    rectangleWasPlaced = TryAddRectHeightFirst(rectWidth, rectHeight, out rectOffsetX, out rectOffsetY, out lowestDeficit);
                    break;
                case EPackedOrder.WidthFirst:
                    rectangleWasPlaced = TryAddRectWidthFirst(rectWidth, rectHeight, out rectOffsetX, out rectOffsetY, out lowestDeficit);
                    break;
                case EPackedOrder.Diagonal:
                    rectangleWasPlaced = TryAddRectDiagonal(rectWidth, rectHeight, out rectOffsetX, out rectOffsetY, out lowestDeficit);
                    break;
                default: 
                    return rectangleWasPlaced;
            }

            // update the max valid width and height
            if(rectangleWasPlaced)
            {
                if(rectOffsetX + requiredWidth > MaxValidWidth)
                {
                    MaxValidWidth = rectOffsetX + requiredWidth;
                }
                if(rectOffsetY + requiredHeight > MaxValidHeight)
                {
                    MaxValidHeight = rectOffsetY + requiredHeight;
                }
            }

            return rectangleWasPlaced;
        }

        private bool TryAddRectHeightFirst(int rectWidth, int rectHeight, out int rectOffsetX, out int rectOffsetY, out int lowestHeightDeficit)
        {
            int offsetX = 0;
            int offsetY = 0;

            int deficit = 0;

            int idxX = 0;
            int idxY = 0;

            int requiredWidth = rectWidth;
            int requiredHeight = rectHeight;

            bool rectangleWasPlaced = false;

            // check the vertical(height) direction first,
            // then check the horizontal(width) direction.
            // row - column traverse
            while (idxX < CanvasCells.ColLength)
            {
                int horizontalCellsCnt;
                int verticalCellsCnt;
                int leftOverWidth;
                int leftOverHeight;

                // find the free space
                while (idxY < CanvasCells.RowLength && CanvasCells.GetData(idxX, idxY))
                {
                    offsetY += CanvasCells.RowHeight(idxY);
                    ++idxY;
                }
                // if we find out a free space, then see if we can place the rectangle there.
                if (idxY < CanvasCells.RowLength && FreeDeficit(Height, offsetY, requiredHeight) <= 0)
                {
                    if (IsAvailable(idxX, idxY, requiredWidth, requiredHeight, out horizontalCellsCnt, out verticalCellsCnt, out leftOverWidth, out leftOverHeight))
                    {
                        // place the rectangle and update the canvas data.
                        PlaceRectangle(idxX, idxY, requiredWidth, requiredHeight, horizontalCellsCnt, verticalCellsCnt, leftOverWidth, leftOverHeight);
                        SpaceLeft -= requiredWidth * requiredHeight;
                        rectangleWasPlaced = true;
                        break;
                    }
                    offsetY += CanvasCells.RowHeight(idxY);
                    ++idxY;
                }

                // check if the height offset has been to the top of the canvas,
                // then we need to move to next column
                int freeHeightDeficit = FreeDeficit(Height, offsetY, requiredHeight);
                if (freeHeightDeficit > 0)
                {
                    offsetY = 0;
                    idxY = 0;

                    offsetX += CanvasCells.ColumnWidth(idxX);
                    ++idxX;
                }

                if ((Width - offsetX) < requiredWidth)
                {
                    rectangleWasPlaced = false;
                    break;
                }

            }

            rectOffsetX = offsetX;
            rectOffsetY = offsetY;
            lowestHeightDeficit = deficit;

            return rectangleWasPlaced;
        }

        private bool TryAddRectWidthFirst(int rectWidth, int rectHeight, out int rectOffsetX, out int rectOffsetY, out int lowestWidthDeficit)
        {
            int offsetX = 0;
            int offsetY = 0;

            int deficit = 0;

            int idxX = 0;
            int idxY = 0;

            int requiredWidth = rectWidth;
            int requiredHeight = rectHeight;

            bool rectangleWasPlaced = false;

            // check the horizontal(width) direction first,
            // then check the vertical(height) direction.
            // row - column traverse
            while (idxY < CanvasCells.RowLength)
            {
                int horizontalCellsCnt;
                int verticalCellsCnt;
                int leftOverWidth;
                int leftOverHeight;

                // find the free space
                while (idxX < CanvasCells.ColLength && CanvasCells.GetData(idxX, idxY))
                {
                    offsetX += CanvasCells.ColumnWidth(idxX);
                    ++idxX;
                }
                // if we find out a free space, then see if we can place the rectangle there.
                if (idxX < CanvasCells.ColLength && FreeDeficit(Width, offsetX, requiredWidth) <= 0)
                {
                    if (IsAvailable(idxX, idxY, requiredWidth, requiredHeight, out horizontalCellsCnt, out verticalCellsCnt, out leftOverWidth, out leftOverHeight))
                    {
                        // place the rectangle and update the canvas data.
                        PlaceRectangle(idxX, idxY, requiredWidth, requiredHeight, horizontalCellsCnt, verticalCellsCnt, leftOverWidth, leftOverHeight);
                        SpaceLeft -= requiredWidth * requiredHeight;
                        rectangleWasPlaced = true;
                        break;
                    }
                    offsetX += CanvasCells.ColumnWidth(idxX);
                    ++idxX;
                }

                // check if the width offset has been to the right most of the canvas,
                // then we need to move to next row
                int freeWidthDeficit = FreeDeficit(Width, offsetX, requiredWidth);
                if (freeWidthDeficit > 0)
                {
                    offsetX = 0;
                    idxX = 0;

                    offsetY += CanvasCells.RowHeight(idxY);
                    ++idxY;
                }

                if ((Height - offsetY) < requiredHeight)
                {
                    rectangleWasPlaced = false;
                    break;
                }

            }

            rectOffsetX = offsetX;
            rectOffsetY = offsetY;
            lowestWidthDeficit = deficit;

            return rectangleWasPlaced;
        }

        private bool TryAddRectDiagonal(int rectWidth, int rectHeight, out int rectOffsetX, out int rectOffsetY, out int lowestDeficit)
        {
            int offsetX = 0;
            int offsetY = 0;

            int deficit = 0;

            int idxX = 0;
            int idxY = 0;

            int requiredWidth = rectWidth;
            int requiredHeight = rectHeight;

            bool rectangleWasPlaced = false;

            while(true)
            {
                int horizontalCellsCnt;
                int verticalCellsCnt;
                int leftOverWidth;
                int leftOverHeight;

                // traverse each cell in the row idxY, until (idxX - 1, idxY)
                int tmpIdxX = 0;
                int tmpOffsetX = 0;
                // find the free space
                while (tmpIdxX < idxX && tmpIdxX < CanvasCells.ColLength && CanvasCells.GetData(tmpIdxX, idxY))
                {
                    tmpOffsetX += CanvasCells.ColumnWidth(tmpIdxX);
                    ++tmpIdxX;
                }
                while (tmpIdxX < idxX && tmpIdxX < CanvasCells.ColLength)
                {
                    if (IsAvailable(tmpIdxX, idxY, requiredWidth, requiredHeight, out horizontalCellsCnt, out verticalCellsCnt, out leftOverWidth, out leftOverHeight))
                    {
                        // place the rectangle and update the canvas data.
                        PlaceRectangle(tmpIdxX, idxY, requiredWidth, requiredHeight, horizontalCellsCnt, verticalCellsCnt, leftOverWidth, leftOverHeight);
                        SpaceLeft -= requiredWidth * requiredHeight;
                        offsetX = tmpOffsetX;
                        rectangleWasPlaced = true;
                        break;
                    }
                    tmpOffsetX += CanvasCells.ColumnWidth(tmpIdxX);
                    ++tmpIdxX;
                }

                if(rectangleWasPlaced)
                {
                    break;
                }

                // traverse each cell in the column idxX, until (idxX, idxY)
                int tmpIdxY = 0;
                int tmpOffsetY = 0;
                // find the free space
                while (tmpIdxY <= idxY && tmpIdxY < CanvasCells.RowLength && CanvasCells.GetData(idxX, tmpIdxY))
                {
                    tmpOffsetY += CanvasCells.RowHeight(tmpIdxY);
                    ++tmpIdxY;
                }
                while (tmpIdxY <= idxY && tmpIdxY < CanvasCells.RowLength)
                {
                    if (IsAvailable(idxX, tmpIdxY, requiredWidth, requiredHeight, out horizontalCellsCnt, out verticalCellsCnt, out leftOverWidth, out leftOverHeight))
                    {
                        // place the rectangle and update the canvas data.
                        PlaceRectangle(idxX, tmpIdxY, requiredWidth, requiredHeight, horizontalCellsCnt, verticalCellsCnt, leftOverWidth, leftOverHeight);
                        SpaceLeft -= requiredWidth * requiredHeight;
                        offsetY = tmpOffsetY;
                        rectangleWasPlaced = true;
                        break;
                    }
                    tmpOffsetY += CanvasCells.RowHeight(tmpIdxY);
                    ++tmpIdxY;
                }
                if (rectangleWasPlaced)
                {
                    break;
                }
                // check if the height offset has been to the top or the right most of the canvas,
                // then we move in diagonal direction, increase idxX and idxY at the same time.
                //int freeHeightDeficit = FreeDeficit(Height, offsetY, requiredHeight);
                //int freeWidthDeficit = FreeDeficit(Width, offsetX, requiredWidth);
                //if (freeHeightDeficit > 0 && freeWidthDeficit > 0)
                //{
                //    offsetX += CanvasCells.ColumnWidth(idxX);
                //    ++idxX;
                //    offsetY += CanvasCells.RowHeight(idxY);
                //    ++idxY;
                //}
                if(idxX <= CanvasCells.ColLength - 1)
                {
                    offsetX += CanvasCells.ColumnWidth(idxX);
                    ++idxX;
                }
                if(idxY <= CanvasCells.RowLength - 1)
                {
                    offsetY += CanvasCells.RowHeight(idxY);
                    ++idxY;
                }               
                if ((Width - offsetX) < requiredWidth && (Height - offsetY) < requiredHeight)
                {
                    rectangleWasPlaced = false;
                    break;
                }
            }          

            rectOffsetX = offsetX;
            rectOffsetY = offsetY;
            lowestDeficit = deficit;

            return rectangleWasPlaced;
        }

        /// <summary>
        /// try to verify the free (idxX, idxY) cell has enough space for the rectangle.
        /// we can combine serveral the neighbour right and neightbour bottom free cells to expand the free space.
        /// </summary>
        /// <param name="idxX"></param>
        /// <param name="idxY"></param>
        /// <param name="requiredWidth"></param>
        /// <param name="requiredHeight"></param>
        /// <param name="horizontalCellsCnt">the number of cells that the rectangle requires horizontally </param>
        /// <param name="verticalCellsCnt">the number of cells that the rectangle requires vertically </param>
        /// <param name="leftOverWidth">the horizontal free space left in the right most cell</param>
        /// <param name="leftOverHeight">the vertical free space left in the bottom most cell</param>
        /// <returns></returns>
        private bool IsAvailable(int idxX, int idxY, int requiredWidth, int requiredHeight,
            out int horizontalCellsCnt, 
            out int verticalCellsCnt,
            out int leftOverWidth,
            out int leftOverHeight)
        {
            horizontalCellsCnt = 0;
            verticalCellsCnt = 0;
            leftOverWidth = 0;
            leftOverHeight = 0;

            int foundWidth = 0;
            int foundHeight = 0;
            int trialX = idxX;
            int trialY = idxY;

            // check all the neighbour cells if enough space for the rectangle
            while(foundHeight < requiredHeight)
            {
                // found the width first
                trialX = idxX;
                foundWidth = 0;

                while(foundWidth < requiredWidth)
                {
                    if(CanvasCells.GetData(trialX, trialY))
                    {
                        // not enough space
                        return false;
                    }
                    foundWidth += CanvasCells.ColumnWidth(trialX);
                    ++trialX;
                    if(trialX > CanvasCells.ColLength)
                    {
                        return false;
                    }
                }

                foundHeight += CanvasCells.RowHeight(trialY);
                ++trialY;
                if(trialY > CanvasCells.RowLength)
                {
                    return false;
                }
            }

            horizontalCellsCnt = trialX - idxX;
            verticalCellsCnt = trialY - idxY;

            leftOverWidth = foundWidth - requiredWidth;
            leftOverHeight = foundHeight - requiredHeight;

            return true;
        }

        /// <summary>
        /// place the rectangle in to the canvas, update the canvas rows and columns
        /// </summary>
        /// <param name="idxX"></param>
        /// <param name="idxY"></param>
        /// <param name="requiredWidth"></param>
        /// <param name="requiredHeight"></param>
        /// <param name="horizontalCellsCnt"></param>
        /// <param name="verticalCellsCnt"></param>
        /// <param name="leftOverWidth"></param>
        /// <param name="leftOverHeight"></param>
        public void PlaceRectangle(int idxX, int idxY, int requiredWidth, int requiredHeight,
            int horizontalCellsCnt,
            int verticalCellsCnt,
            int leftOverWidth,
            int leftOverHeight)
        {
            if(leftOverWidth > 0)
            {
                int xFarRightColumn = idxX + horizontalCellsCnt - 1;
                CanvasCells.InsertColumn(xFarRightColumn, leftOverWidth);
            }

            if(leftOverHeight > 0)
            {
                int yFarBottomRow = idxY + verticalCellsCnt - 1;
                CanvasCells.InsertRow(yFarBottomRow, leftOverHeight);
            }

            for (int i = idxX + horizontalCellsCnt - 1; i >= idxX; i--)
            {
                for (int j = idxY + verticalCellsCnt - 1; j >= idxY; j--)
                {
                    CanvasCells.SetData(i, j, true);
                }
            }
        }

        /// <summary>
        /// calculate the deficit height
        /// </summary>
        /// <param name="canvasHeight"></param>
        /// <param name="offsetY"></param>
        /// <param name="requiredHeight"></param>
        /// <returns></returns>
        public int FreeDeficit(int canvasSize, int offset, int requiredSize)
        {
            int offsetSize = canvasSize - offset;
            int freeDeficit = requiredSize - offsetSize;
            return freeDeficit;
        }

        /// <summary>
        /// Get the min valid rectangle size
        /// </summary>
        /// <returns>lenght 2 int array, index 0 is width, index 1 is height</returns>
        public void GetMinValidRect(out int width, out int height)
        {
            width = MaxValidWidth;
            height = MaxValidHeight;
        }
    }

    public class Dynamic2DArray<T>
    {
        /// <summary>
        /// Describe a column or row, record the size
        /// Index is the real intuitive index.
        /// </summary>
        private struct Dimenssion
        {
            public int Index { get; set; }
            public int Size { get; set; }
            
        }

        private Dimenssion[] _columns;
        private Dimenssion[] _rows;

        public int ColLength { get; private set; }
        public int RowLength { get; private set; }

        /// <summary>
        /// record the space status, usually use bool to show if the space free or not.
        /// </summary>
        private T[,] _data; 
        
        public Dynamic2DArray()
        {

        }

        /// <summary>
        /// Init 
        /// </summary>
        /// <param name="SizeX"></param>
        /// <param name="SizeY"></param>
        /// <param name="DefaultValue"></param>
        /// <returns></returns>
        public bool Init(int sizeX, int sizeY, T defaultValue)
        {
            // cols and rows size will expand in double each time in the future.
            _columns = new Dimenssion[sizeX];
            _rows = new Dimenssion[sizeY];

            _data = new T[sizeX, sizeY];

            ColLength = 1;
            RowLength = 1;

            _columns[0].Index = 0;
            _columns[0].Size = (short)sizeX;

            _rows[0].Index = 0;
            _rows[0].Size = (short)sizeY;

            _data[0, 0] = defaultValue;

            return true;
        }

        public T GetData(int x, int y)
        {
            return _data[_columns[x].Index, _rows[y].Index];
        }

        public void SetData(int x, int y, T value)
        {
            _data[_columns[x].Index, _rows[y].Index] = value;
        }

        public int ColumnWidth(int x)
        {
            return _columns[x].Size;
        }

        public int RowHeight(int y)
        {
            return _rows[y].Size;
        }

        /// <summary>
        /// split the row y, make the y+1 as the new row
        /// </summary>
        /// <param name="y">the row will be splited</param>
        /// <param name="newHeight">the new row's height</param>
        public void InsertRow(int y, int newHeight)
        {
            if(y >= RowLength)
            {
                //TODO: error
            }

            int realY = _rows[y].Index;
            for(int x = 0; x < ColLength; ++x)
            {
                _data[x, RowLength] = _data[x, realY];
            }

            // if the row y not the last row, need to shift the rows which come after the y.
            if(y < (RowLength - 1))
            {
                Array.Copy(_rows, y + 1, _rows, y + 2, RowLength - y - 1);
            }

            // make the last Index point to the new row.
            _rows[y + 1].Index = RowLength;

            int oldHeight = _rows[y].Size;
            int newHeightExistingRow = oldHeight - newHeight;
            _rows[y + 1].Size = newHeight;
            _rows[y].Size = newHeightExistingRow;

            ++RowLength;
        }

        public void InsertColumn(int x, int newWidth)
        {
            if (x >= ColLength)
            {
                //TODO: error
            }

            int realX = _columns[x].Index;
            for (int y = 0; y < RowLength; ++y)
            {
                _data[ColLength, y] = _data[realX, y];
            }

            // if the column x not the last column, need to shift the columns which come after the x.
            if (x < (ColLength - 1))
            {
                Array.Copy(_columns, x + 1, _columns, x + 2, ColLength - x - 1);
            }

            // make the last Index point to the new row.
            _columns[x + 1].Index = ColLength;

            int oldWidth = _columns[x].Size;
            int newWidthExistingRow = oldWidth - newWidth;
            _columns[x + 1].Size = newWidth;
            _columns[x].Size = newWidthExistingRow;

            ++ColLength;
        }

        
    }
}